import androidx.compose.desktop.ui.tooling.preview.Preview
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import firebase.FirebaseAuthService
import kotlinx.coroutines.launch
import ui.screens.*
import ui.data.User
import java.io.File
import ui.data.UserRole

// ------------------- APP STATES -------------------
enum class AppState { LOGIN, IMS, ADMIN_CREATE_USER }

// ------------------- USER -------------------
data class User(val email: String, val role: String)

// ------------------- LOGIN SCREEN -------------------
@Composable
fun LoginScreen(
    authService: FirebaseAuthService,
    onLoginSuccess: (UserRole, String) -> Unit,
    onError: (String) -> Unit
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Purfect IMS Login", fontSize = 26.sp)

        Spacer(Modifier.height(20.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email") },
            modifier = Modifier.fillMaxWidth(0.7f)
        )

        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(0.7f)
        )

        Spacer(Modifier.height(20.dp))

        Button(
            onClick = {
                loading = true
                scope.launch {
                    val res = authService.signIn(email, password)

                    if (res.error != null) {
                        message = res.error!!.message
                        onError(message)
                    } else {
                        val role = when {
                            email.endsWith("@admin.com") -> UserRole.ADMIN
                            email.endsWith("@manager.com") -> UserRole.MANAGER
                            email.endsWith("@employee.com") -> UserRole.EMPLOYEE
                            else -> UserRole.EMPLOYEE
                        }
                        onLoginSuccess(role, email)
                    }
                    loading = false
                }
            },
            enabled = !loading,
            modifier = Modifier.fillMaxWidth(0.7f).height(52.dp)
        ) {
            Text(if (loading) "Loading…" else "Login")
        }

        if (message.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            Text(message, color = MaterialTheme.colors.error)
        }
    }
}

// ------------------- NAVIGATION BUTTON -------------------
@Composable
fun NavButton(name: String, selected: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            backgroundColor = if (selected) Color(0xFF1E40AF) else Color(0xFF3B82F6),
            contentColor = Color.White
        ),
        modifier = Modifier.fillMaxWidth().height(50.dp)
    ) {
        Text(name)
    }
}

// ------------------- MAIN IMS DASHBOARD -------------------
@Composable
fun IMSApp(
    user: User,
    onLogout: () -> Unit,
    onCreateUser: () -> Unit
) {
    var selected by remember { mutableStateOf("Dashboard") }

    val menu = when (user.role.uppercase()) {
        "ADMIN" -> listOf("Dashboard", "Adjust", "Inventory", "Purchase", "Sales", "Reports", "Create User")
        "MANAGER" -> listOf("Dashboard", "Adjust", "Inventory", "Purchase", "Sales", "Reports")
        else -> listOf("Dashboard", "Inventory")
    }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Purfect IMS • ${user.email}", color = Color.White) },
            backgroundColor = Color(0xFF1E40AF),
            actions = {
                Button(
                    onClick = onLogout,
                    colors = ButtonDefaults.buttonColors(backgroundColor = Color.Red)
                ) { Text("Logout", color = Color.White) }
            }
        )

        Row(Modifier.fillMaxSize()) {
            // Sidebar
            Column(
                Modifier.width(220.dp).fillMaxHeight().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                menu.forEach { item ->
                    NavButton(item, selected == item) {
                        if (item == "Create User") {
                            onCreateUser()
                        } else {
                            selected = item
                        }
                    }
                }
            }

            // Main Content
            Box(Modifier.fillMaxSize().padding(30.dp)) {
                when (selected) {
                    "Dashboard"  -> Text("Welcome, ${user.role}!", fontSize = 32.sp)
                    "Adjust"     -> AdjustScreen()
                    "Inventory"  -> InventoryScreen(currentUser = user)
                    "Purchase"   -> PurchaseScreen()
                    "Sales"      -> SalesScreen()
                    "Reports"    -> ReportScreen()
                    else         -> Text("Welcome to Purfect IMS", fontSize = 28.sp)
                }
            }
        }
    }
}

// ------------------- MAIN APPLICATION ROUTER -------------------
@Composable
fun MainApp() {
    var appState by remember { mutableStateOf(AppState.LOGIN) }
    var currentUser by remember { mutableStateOf<User?>(null) }

    val authService = remember {
        FirebaseAuthService("AIzaSyBXbna5Wwq6bZbSFQsuq1Mwu1DR4XwQUhc")
    }

    MaterialTheme {
        when (appState) {
            AppState.LOGIN -> LoginScreen(
                authService = authService,
                onLoginSuccess = { role, email ->
                    currentUser = User(email = email, role = role.name)
                    appState = AppState.IMS
                },
                onError = { println("Login failed: $it") }
            )

            AppState.IMS -> currentUser?.let { user ->
                IMSApp(
                    user = user,
                    onLogout = {
                        currentUser = null
                        appState = AppState.LOGIN
                    },
                    onCreateUser = {
                        if (user.role.uppercase() == "ADMIN") {
                            appState = AppState.ADMIN_CREATE_USER
                        }
                    }
                )
            }

            AppState.ADMIN_CREATE_USER -> AdminCreateUserScreen(
                authService = authService,
                onSuccess = { appState = AppState.IMS },
                onError = { error -> println("Create user failed: $error") }
            )
        }
    }
}

// ------------------- ENTRY POINT -------------------
fun main() = application {
            Window(onCloseRequest = {
            // This runs when you close the app
            File("transactions.json").delete()   // Deletes the file!
            exitApplication()
        },

        title = "Purfect IMS - Inventory Management System"
    ) {
        MainApp()
    }
}