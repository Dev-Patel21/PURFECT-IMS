package ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import firebase.FirebaseAuthService
import kotlinx.coroutines.launch
import ui.data.UserRole

@Composable
fun LoginScreen(
    authService: FirebaseAuthService,
    onLoginSuccess: (UserRole, String) -> Unit,
    onError: (String) -> Unit
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {

        Text("Purfect IMS Login", fontSize = 26.sp)

        Spacer(Modifier.height(20.dp))

        OutlinedTextField(
            email,
            { email = it },
            label = { Text("Email") },
            modifier = Modifier.fillMaxWidth(0.7f)
        )

        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            password,
            { password = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(0.7f)
        )

        Spacer(Modifier.height(20.dp))

        Button(
            onClick = {
                loading = true
                scope.launch {
                    val res = authService.signIn(email, password)

                    if (res.error != null) {
                        message = res.error!!.message
                        onError(message)
                    } else {
                        val role = when {
                            email.endsWith("@admin.com") -> UserRole.ADMIN
                            email.endsWith("@manager.com") -> UserRole.MANAGER
                            email.endsWith("@employee.com") -> UserRole.EMPLOYEE
                            else -> UserRole.EMPLOYEE  // default
                        }
                        onLoginSuccess(role, email)
                    }
                    loading = false
                }
            },
            enabled = !loading,
            modifier = Modifier.fillMaxWidth(0.7f).height(52.dp)
        ) {
            Text(if (loading) "Loading…" else "Login")
        }

        if (message.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            Text(message, color = MaterialTheme.colors.error)
        }
    }
}
