package ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ui.data.InventoryRepository
import ui.data.TransactionRepository

@Composable
fun SalesScreen() {
    val items = InventoryRepository.getItems()
    var selectedItem by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf("") }

    Card(modifier = Modifier.fillMaxSize().padding(8.dp), elevation = 8.dp) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {

            Text("Sales Entry", style = MaterialTheme.typography.h6)

            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (selectedItem.isEmpty()) "Select Item" else selectedItem)
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    items.forEach { item ->
                        DropdownMenuItem(onClick = {
                            selectedItem = item.name
                            expanded = false
                        }) { Text(item.name) }
                    }
                }
            }

            OutlinedTextField(
                value = qty,
                onValueChange = { qty = it },
                label = { Text("Quantity Sold") },
                modifier = Modifier.fillMaxWidth()
            )

            if (errorMsg.isNotEmpty()) Text(errorMsg, color = MaterialTheme.colors.error)

            Button(onClick = {
                val quantity = qty.toIntOrNull() ?: 0
                val stock = InventoryRepository.getItems().find { it.name == selectedItem }?.quantity ?: 0
                if (selectedItem.isEmpty()) errorMsg = "Please select an item"
                else if (quantity <= 0) errorMsg = "Enter a valid quantity"
                else if (quantity > stock) errorMsg = "Cannot sell more than available stock ($stock)"
                else {
                    InventoryRepository.sellItem(selectedItem, quantity)
                    TransactionRepository.addTransaction(selectedItem, quantity, "Sold")
                    qty = ""
                    errorMsg = ""
                }
            }, modifier = Modifier.fillMaxWidth()) { Text("Record Sale") }

            Spacer(modifier = Modifier.height(16.dp))

            TransactionHistoryTable(TransactionRepository.getTransactions())
        }
    }
}
