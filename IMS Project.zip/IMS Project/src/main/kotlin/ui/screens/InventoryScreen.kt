package ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ui.data.InventoryRepository
import ui.data.User

@Composable
fun InventoryScreen(currentUser: User) {

    var searchQuery by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var minQty by remember { mutableStateOf("") }

    // Get all items and filter based on search
    val allItems = InventoryRepository.getItems()
    val filteredItems = if (searchQuery.isBlank()) {
        allItems
    } else {
        allItems.filter { item ->
            item.name.contains(searchQuery, ignoreCase = true)
        }
    }

    val isAdminOrManager = currentUser.role.uppercase() in listOf("ADMIN", "MANAGER")

    Card(
        modifier = Modifier.fillMaxSize().padding(12.dp),
        elevation = 12.dp,
        backgroundColor = Color(0xFFF8FAFC)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {

            Text("Inventory Management", fontSize = 28.sp, fontWeight = FontWeight.Bold)

            Spacer(Modifier.height(16.dp))

            // SEARCH BAR
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Search Items") },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = null, tint = Color.Gray)
                },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                colors = TextFieldDefaults.outlinedTextFieldColors(
                    focusedBorderColor = Color(0xFF1E40AF),
                    unfocusedBorderColor = Color.LightGray
                )
            )

            Spacer(Modifier.height(20.dp))

            // ADD ITEM SECTION — ONLY ADMIN & MANAGER
            if (isAdminOrManager) {
                Card(elevation = 6.dp, backgroundColor = Color(0xFFE3F2FD), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Add New Item", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)

                        Spacer(Modifier.height(12.dp))

                        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Item Name") }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = minQty, onValueChange = { if (it.all { char -> char.isDigit() || char == '-' }) minQty = it }, label = { Text("Minimum Qty") }, modifier = Modifier.fillMaxWidth())

                        Spacer(Modifier.height(16.dp))

                        Button(onClick = {
                            if (name.isNotBlank() && minQty.isNotBlank()) {
                                InventoryRepository.addItem(name.trim(), minQty.toInt())
                                name = ""
                                minQty = ""
                            }
                        }, modifier = Modifier.align(Alignment.End)) {
                            Text("Add Item")
                        }
                    }
                }
                Spacer(Modifier.height(20.dp))
            } else {
                Card(backgroundColor = Color(0xFFFFF3E0), modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(16.dp)) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFFFF6D00), modifier = Modifier.size(32.dp))
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("Add Items Restricted", fontWeight = FontWeight.SemiBold, color = Color(0xFFFF6D00))
                            Text("Only Admin and Managers can add items.", color = Color.Gray)
                        }
                    }
                }
            }

            // RESULTS COUNT
            Text(
                "${filteredItems.size} item${if (filteredItems.size != 1) "s" else ""} found",
                fontSize = 16.sp,
                color = if (filteredItems.size == allItems.size) Color.Gray else Color(0xFF1E40AF),
                fontWeight = FontWeight.Medium
            )

            Spacer(Modifier.height(12.dp))

            // INVENTORY LIST
            if (filteredItems.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    if (searchQuery.isBlank()) {
                        Text("No items in inventory yet.", color = Color.Gray, fontSize = 18.sp)
                    } else {
                        Text("No items match \"$searchQuery\"", color = Color.Gray, fontSize = 18.sp)
                    }
                }
            } else {
                LazyColumn(modifier = Modifier.weight(1f)) {
                    items(filteredItems) { item ->
                        Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), elevation = 4.dp) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(item.name, fontWeight = FontWeight.Medium, fontSize = 16.sp)
                                    Text("Min Qty: ${item.minQty}", color = Color.Gray, fontSize = 14.sp)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        "Qty: ${item.quantity}",
                                        fontWeight = FontWeight.Bold,
                                        color = if (item.quantity < item.minQty) MaterialTheme.colors.error else Color.Unspecified
                                    )
                                    if (item.quantity < item.minQty) {
                                        Spacer(Modifier.width(8.dp))
                                        Text("LOW STOCK!", color = MaterialTheme.colors.error, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}