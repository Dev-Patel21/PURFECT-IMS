package ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ui.data.InventoryRepository
import ui.data.TransactionRepository
import ui.data.InventoryItem
import ui.data.TransactionEntry

@Composable
fun ReportScreen() {
    var selectedReport by remember { mutableStateOf("Purchase") }
    var searchQuery by remember { mutableStateOf("") }
    val reportOptions = listOf("Purchase", "Sales", "Adjustment", "Low Stock")

    // Live data from repository
    val allTransactions by TransactionRepository.transactionsFlow.collectAsState()
    val allItems by remember { mutableStateOf(InventoryRepository.getItems()) } // or make this live too later

    Card(modifier = Modifier.fillMaxSize().padding(8.dp), elevation = 8.dp) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Reports", style = MaterialTheme.typography.h6)

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Search by Item Name") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            // Report Type Dropdown
            var expanded by remember { mutableStateOf(false) }
            Box {
                OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(selectedReport)
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    reportOptions.forEach { option ->
                        DropdownMenuItem(onClick = {
                            selectedReport = option
                            expanded = false
                        }) { Text(option) }
                    }
                }
            }

            Divider()

            // Filtered Data
            val filteredTransactions = allTransactions.filter { tx ->
                val matchesType = when (selectedReport) {
                    "Purchase" -> tx.action.contains("Purchased", true)
                    "Sales" -> tx.action.contains("Sold", true)
                    "Adjustment" -> tx.action.contains("Adjusted", true)
                    else -> true
                }
                val matchesSearch = tx.itemName.contains(searchQuery, ignoreCase = true)
                matchesType && (searchQuery.isBlank() || matchesSearch)
            }

            val lowStockItems = allItems.filter { it.quantity < it.minQty &&
                    (searchQuery.isBlank() || it.name.contains(searchQuery, ignoreCase = true)) }

            when (selectedReport) {
                "Low Stock" -> LowStockTable(lowStockItems)
                else -> TransactionTable(filteredTransactions)
            }
        }
    }
}

@Composable
fun TransactionTable(transactions: List<TransactionEntry>) {
    Column {
        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Text("Date/Time", modifier = Modifier.weight(1f))
            Text("Item Name", modifier = Modifier.weight(1f))
            Text("Qty", modifier = Modifier.weight(1f))
            Text("Stock After", modifier = Modifier.weight(1f))
            Text("Reason/Action", modifier = Modifier.weight(1f))
        }
        Divider()
        transactions.forEach { t ->
            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Text(t.timestamp, modifier = Modifier.weight(1f))
                Text(t.itemName, modifier = Modifier.weight(1f))
                Text("${t.quantity}", modifier = Modifier.weight(1f))
                Text("${t.stockAvailable}", modifier = Modifier.weight(1f))
                Text(t.action, modifier = Modifier.weight(1f))
            }
            Divider()
        }
        if (transactions.isEmpty()) {
            Text("No transactions found.", modifier = Modifier.padding(top = 16.dp))
        }
    }
}

@Composable
fun LowStockTable(items: List<InventoryItem>) {
    Column {
        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Text("Item Name", modifier = Modifier.weight(1f))
            Text("Current Qty", modifier = Modifier.weight(1f))
            Text("Minimum Qty", modifier = Modifier.weight(1f))
        }
        Divider()
        items.forEach { item ->
            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Text(item.name, modifier = Modifier.weight(1f))
                Text("${item.quantity}", modifier = Modifier.weight(1f))
                Text("${item.minQty}", modifier = Modifier.weight(1f))
            }
            Divider()
        }
        if (items.isEmpty()) {
            Text("No low stock items.", modifier = Modifier.padding(top = 16.dp))
        }
    }
}