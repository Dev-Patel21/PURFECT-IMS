package ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import ui.data.InventoryRepository
import ui.data.TransactionRepository
import androidx.compose.ui.text.font.FontWeight

@Composable
fun AdjustScreen() {
    val items = InventoryRepository.getItems()
    var selectedItem by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf("") }

    var selectedReason by remember { mutableStateOf("") }
    val adjustmentReasons = listOf("Damaged", "Lost", "Found", "Correction", "Other")

    Card(modifier = Modifier.fillMaxSize().padding(8.dp), elevation = 8.dp) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {

            Text("Adjust Inventory (Lost/Found)", style = MaterialTheme.typography.h6)

            // Dropdown to select item
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (selectedItem.isEmpty()) "Select Item" else selectedItem)
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    items.forEach { item ->
                        DropdownMenuItem(onClick = {
                            selectedItem = item.name
                            expanded = false
                        }) { Text(item.name) }
                    }
                }
            }

            // Quantity input
            OutlinedTextField(
                value = qty,
                onValueChange = { qty = it },
                label = { Text("Adjustment (+/-)") },
                modifier = Modifier.fillMaxWidth()
            )
            Text("Select Reason:", fontWeight = FontWeight.Medium)

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 32.dp),        // Controls how close to center they are
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.Top
            ) {
                // Left Column
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    adjustmentReasons.take((adjustmentReasons.size + 1) / 2).forEach { reason ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = selectedReason == reason,
                                onClick = { selectedReason = reason }
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(reason)
                        }
                    }
                }

                Spacer(Modifier.width(200.dp))  // Distance between the two columns

                // Right Column
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    adjustmentReasons.drop((adjustmentReasons.size + 1) / 2).forEach { reason ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = selectedReason == reason,
                                onClick = { selectedReason = reason }
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(reason)
                        }
                    }
                }
            }
            if (errorMsg.isNotEmpty()) Text(errorMsg, color = MaterialTheme.colors.error)

            // Apply adjustment
            Button(onClick = {
                val adjustment = qty.toIntOrNull() ?: 0
                val itemStock = InventoryRepository.getItems().find { it.name == selectedItem }?.quantity ?: 0

                if (selectedItem.isEmpty()) errorMsg = "Please select an item"
                else if (adjustment == 0) errorMsg = "Enter a non-zero adjustment"
                else if (adjustment < 0 && itemStock + adjustment < 0)
                    errorMsg = "Cannot reduce more than available stock ($itemStock)"
                else {
                    InventoryRepository.adjustStock(selectedItem, adjustment)
                    val reasonText = if (selectedReason.isEmpty()) "No reason" else selectedReason
                    TransactionRepository.addTransaction(selectedItem, adjustment, "Adjusted: $reasonText")
                    qty = ""
                    selectedReason = ""
                    errorMsg = ""
                }
            }, modifier = Modifier.fillMaxWidth()) {
                Text("Apply Adjustment")
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Transaction history table
            val history = TransactionRepository.getTransactions()
            TransactionHistoryTable(history)
        }
    }
}
