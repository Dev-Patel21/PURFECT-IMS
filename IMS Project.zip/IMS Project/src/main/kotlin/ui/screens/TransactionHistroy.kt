package ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ui.data.TransactionEntry

@Composable
fun TransactionHistoryTable(history: List<TransactionEntry>) {
    var searchQuery by remember { mutableStateOf("") }

    // Filter transactions by item name (case-insensitive)
    val filteredHistory = remember(searchQuery, history) {
        if (searchQuery.isBlank()) {
            history
        } else {
            history.filter { it.itemName.contains(searchQuery, ignoreCase = true) }
        }
    }

    Column(modifier = Modifier.fillMaxWidth()) {

        // SEARCH BAR with icon
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("Search by Item Name") },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = Color.Gray
                )
            },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            colors = TextFieldDefaults.outlinedTextFieldColors(
                focusedBorderColor = Color(0xFF1E40AF),
                unfocusedBorderColor = Color.LightGray
            )
        )

        // RESULTS COUNT
        Text(
            text = "${filteredHistory.size} transaction${if (filteredHistory.size != 1) "s" else ""} found",
            fontSize = 14.sp,
            color = if (filteredHistory.size == history.size) Color.Gray else Color(0xFF1E40AF),
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        // TABLE HEADER
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFE2E8F0))
                .padding(vertical = 12.dp, horizontal = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Date & Time", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1.2f))
            Text("Item Name", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Text("Qty", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(0.6f))
            Text("Action", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Text("Stock After", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(0.8f))
        }

        // TRANSACTION LIST
        if (filteredHistory.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (searchQuery.isBlank()) {
                        "No transactions yet."
                    } else {
                        "No transactions found for \"$searchQuery\""
                    },
                    color = Color.Gray,
                    fontSize = 16.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                items(filteredHistory) { entry ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp, horizontal = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(entry.timestamp, modifier = Modifier.weight(1.2f), fontSize = 14.sp)
                        Text(entry.itemName, modifier = Modifier.weight(1f), fontSize = 14.sp)
                        Text(
                            entry.quantity.toString(),
                            modifier = Modifier.weight(0.6f),
                            fontSize = 14.sp,
                            color = if (entry.quantity < 0) MaterialTheme.colors.error else Color.Unspecified
                        )
                        Text(entry.action, modifier = Modifier.weight(1f), fontSize = 14.sp)
                        Text(entry.stockAvailable.toString(), modifier = Modifier.weight(0.8f), fontSize = 14.sp)
                    }
                    Divider(color = Color.LightGray.copy(alpha = 0.3f))
                }
            }
        }
    }
}