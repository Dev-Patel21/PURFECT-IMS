package firebase

import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

private val json = Json { ignoreUnknownKeys = true }
private val httpClient = HttpClient {
    install(ContentNegotiation) { json(json) }
}

@Serializable
data class SignInRequest(
    val email: String,
    val password: String,
    val returnSecureToken: Boolean = true
)

@Serializable
data class SignInResponse(
    val localId: String? = null,
    val idToken: String? = null,
    val email: String? = null,
    val error: ErrorResponse? = null
)

@Serializable
data class ErrorResponse(val message: String)

class FirebaseAuthService(private val apiKey: String) {

    private val signInUrl = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=$apiKey"
    private val signUpUrl = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=$apiKey"

    suspend fun signIn(email: String, password: String): SignInResponse = withContext(Dispatchers.IO) {
        try {
            val response: SignInResponse = httpClient.post(signInUrl) {
                contentType(ContentType.Application.Json)
                setBody(SignInRequest(email, password))
            }.body()
            response
        } catch (e: Exception) {
            SignInResponse(error = ErrorResponse(e.message ?: "Network error"))
        }
    }

    suspend fun signUp(email: String, password: String): SignInResponse = withContext(Dispatchers.IO) {
        try {
            val response: SignInResponse = httpClient.post(signUpUrl) {
                contentType(ContentType.Application.Json)
                setBody(SignInRequest(email, password))
            }.body()
            response
        } catch (e: Exception) {
            SignInResponse(error = ErrorResponse(e.message ?: "Signup failed"))
        }
    }
}