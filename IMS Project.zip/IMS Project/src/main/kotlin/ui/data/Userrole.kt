package model

enum class UserRole {
    ADMIN,
    MANAGER,
    EMPLOYEE
}
