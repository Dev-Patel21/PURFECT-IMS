package ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import firebase.FirebaseAuthService

@Composable
fun AdminCreateUserScreen(
    authService: FirebaseAuthService,
    onSuccess: () -> Unit,
    onError: (String) -> Unit
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
    ) {

        Text(
            text = "Create New User",
            style = MaterialTheme.typography.h5
        )

        Spacer(modifier = Modifier.height(20.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("User Email") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(25.dp))

        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                scope.launch {
                    try {
                        val response = authService.signUp(email, password)

                        if (response.error != null) {
                            onError(response.error.message)
                            return@launch
                        }

                        if (response.localId == null) {
                            onError("Signup failed: No UID returned")
                            return@launch
                        }

                        // No role saving needed — role comes from email domain.
                        onSuccess()

                    } catch (e: Exception) {
                        onError(e.message ?: "Unknown error")
                    }
                }
            }
        ) {
            Text("Create User")
        }
    }
}
