package ui.data

import kotlinx.serialization.json.Json
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.snapshots.SnapshotStateList
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object TransactionRepository {
    private val file = File("transactions.json")
    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }

    private val _transactions = mutableStateListOf<TransactionEntry>()

    // NEW: Live reactive flow
    private val _transactionsFlow = MutableStateFlow<List<TransactionEntry>>(emptyList())
    val transactionsFlow: StateFlow<List<TransactionEntry>> = _transactionsFlow.asStateFlow()

    init {
        load()
    }

    private fun load() {
        if (file.exists()) {
            val content = file.readText()
            if (content.isNotBlank()) {
                try {
                    val list: List<TransactionEntry> = json.decodeFromString(content)
                    _transactions.clear()
                    _transactions.addAll(list)
                    _transactionsFlow.value = list  // Update flow
                } catch (e: Exception) {
                    e.printStackTrace()
                    _transactions.clear()
                }
            }
        }
    }

    private fun save() {
        file.writeText(json.encodeToString(_transactions.toList()))
    }

    fun addTransaction(itemName: String, quantity: Int, action: String) {
        val stockAvailable = InventoryRepository.getItems()
            .find { it.name == itemName }?.quantity ?: 0

        val timestamp = LocalDateTime.now()
            .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))

        val entry = TransactionEntry(itemName, quantity, action, stockAvailable, timestamp)

        _transactions.add(entry)
        _transactionsFlow.value = _transactions.toList()  // This triggers instant UI update!
        save()
    }

    fun getTransactions(): List<TransactionEntry> = _transactions.toList()

    // Optional: Clear all
    fun clear() {
        _transactions.clear()
        _transactionsFlow.value = emptyList()
        file.delete()
    }
}