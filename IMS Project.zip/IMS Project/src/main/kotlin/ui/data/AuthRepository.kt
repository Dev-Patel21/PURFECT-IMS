package ui.data

class AuthRepository {
}