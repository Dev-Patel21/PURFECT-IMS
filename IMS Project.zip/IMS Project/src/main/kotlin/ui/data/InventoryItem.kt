package ui.data

import kotlinx.serialization.Serializable

@Serializable
data class InventoryItem(
    val name: String,
    var quantity: Int,
    val minQty: Int
)
