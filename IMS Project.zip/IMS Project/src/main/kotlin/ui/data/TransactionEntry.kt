package ui.data

import kotlinx.serialization.Serializable

@Serializable
data class TransactionEntry(
    val itemName: String,
    val quantity: Int,
    val action: String,  // "Purchased", "Sold", "Adjusted"
    val stockAvailable: Int,
    val timestamp: String
)
