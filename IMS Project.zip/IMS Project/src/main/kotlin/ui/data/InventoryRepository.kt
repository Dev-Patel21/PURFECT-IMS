package ui.data

import androidx.compose.runtime.mutableStateListOf

object InventoryRepository {

    private val _items = mutableStateListOf<InventoryItem>()

    // Return immutable list for reading
    fun getItems(): List<InventoryItem> = _items.toList()

    // Add a new inventory item
    fun addItem(name: String, minQty: Int) {
        if (_items.none { it.name == name }) {
            _items.add(InventoryItem(name, 0, minQty))
        }
    }

    // Add stock to an item
    fun addStock(itemName: String, qty: Int) {
        val item = _items.find { it.name == itemName }
        if (item != null) {
            item.quantity += qty
        }
    }

    // Sell item with stock check
    fun sellItem(itemName: String, qty: Int): Boolean {
        val item = _items.find { it.name == itemName }
        return if (item != null && item.quantity >= qty) {
            item.quantity -= qty
            true
        } else {
            false
        }
    }

    // Adjust stock (allow negative for loss, but not below zero)
    fun adjustStock(itemName: String, qtyChange: Int): Boolean {
        val item = _items.find { it.name == itemName }
        return if (item != null && item.quantity + qtyChange >= 0) {
            item.quantity += qtyChange
            true
        } else {
            false
        }
    }
}
