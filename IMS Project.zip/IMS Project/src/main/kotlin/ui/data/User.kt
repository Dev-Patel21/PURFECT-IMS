package ui.data

data class User(
    val email: String,
    val role: String

)


enum class UserRole {
    ADMIN,
    MANAGER,
    EMPLOYEE
}
