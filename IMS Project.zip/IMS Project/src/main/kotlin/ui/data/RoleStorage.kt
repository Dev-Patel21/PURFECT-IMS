package ui.data

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File

object RoleStorage {

    private val file = File("roles.json")
    private val gson = Gson()

    private var users: MutableList<User> = mutableListOf()

    init {
        if (file.exists()) {
            val type = object : TypeToken<List<User>>() {}.type
            users = gson.fromJson(file.readText(), type) ?: mutableListOf()
        }
    }

    fun saveUserRole(user: User) {
        users.add(user)
        file.writeText(gson.toJson(users))
    }
}

//    fun getUserRoleById(uid: String): UserRole? {
//        return users.find { it.userId == uid }?.role
//    }
//}
